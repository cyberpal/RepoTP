﻿CREATE LOGIN [Usr_Pentaho]
    WITH PASSWORD = N'b{sljsoJs#meq!bk|okKt|w7msFT7_&#$!~<{reuwsljndge', SID = 0x63F93A1716BC204E9A5F990D51032E5A, DEFAULT_LANGUAGE = [us_english], CHECK_POLICY = OFF;

