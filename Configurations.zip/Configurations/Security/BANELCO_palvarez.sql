﻿CREATE USER [BANELCO\palvarez] FOR LOGIN [BANELCO\palvarez];

