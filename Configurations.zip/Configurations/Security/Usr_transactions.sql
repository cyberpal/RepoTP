﻿CREATE USER [Usr_transactions] FOR LOGIN [Usr_transactions];

