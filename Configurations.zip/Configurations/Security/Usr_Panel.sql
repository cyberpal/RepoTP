﻿CREATE USER [Usr_Panel] FOR LOGIN [Usr_Panel];

