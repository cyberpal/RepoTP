﻿CREATE USER [BANELCO\usuarioautoldap] FOR LOGIN [BANELCO\usuarioautoldap];

