﻿CREATE USER [BANELCO\jbednarz] FOR LOGIN [BANELCO\jbednarz];

