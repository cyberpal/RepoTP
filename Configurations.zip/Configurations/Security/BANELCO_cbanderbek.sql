﻿CREATE USER [BANELCO\cbanderbek] FOR LOGIN [BANELCO\cbanderbek];

