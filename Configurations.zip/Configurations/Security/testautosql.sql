﻿CREATE USER [testautosql] FOR LOGIN [testautosql];

