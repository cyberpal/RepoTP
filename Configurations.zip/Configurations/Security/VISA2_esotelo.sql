﻿CREATE USER [VISA2\esotelo] FOR LOGIN [VISA2\esotelo];

