﻿CREATE USER [usr_DW_odbc] FOR LOGIN [usr_DW_odbc];

