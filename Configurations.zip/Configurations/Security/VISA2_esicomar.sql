﻿CREATE USER [VISA2\esicomar] FOR LOGIN [VISA2\esicomar];

