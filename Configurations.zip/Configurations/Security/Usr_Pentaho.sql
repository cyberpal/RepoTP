﻿CREATE USER [Usr_Pentaho] FOR LOGIN [Usr_Pentaho];

