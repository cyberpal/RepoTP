﻿CREATE USER [BANELCO\lespindola] FOR LOGIN [BANELCO\lespindola];

