﻿CREATE USER [BANELCO\fscarpello] FOR LOGIN [BANELCO\fscarpello];

