﻿CREATE USER [BANELCO\dbriasco] FOR LOGIN [BANELCO\dbriasco];

