﻿ALTER ROLE [db_owner] ADD MEMBER [Usr_Configurations];


GO
ALTER ROLE [db_owner] ADD MEMBER [VISA2\VSIMADIM];


GO
ALTER ROLE [db_owner] ADD MEMBER [VISA2\Vsidaher];


GO
ALTER ROLE [db_owner] ADD MEMBER [VISA2\ESIPAROM];


GO
ALTER ROLE [db_owner] ADD MEMBER [VISA2\ESIGACAM];


GO
ALTER ROLE [db_owner] ADD MEMBER [Usr_Panel];


GO
ALTER ROLE [db_owner] ADD MEMBER [VISA2\VSIJAGUT];


GO
ALTER ROLE [db_owner] ADD MEMBER [VISA2\mbravo];


GO
ALTER ROLE [db_owner] ADD MEMBER [VISA2\amartinez];


GO
ALTER ROLE [db_owner] ADD MEMBER [VISA2\715A4DC1E4F74831A06];


GO
ALTER ROLE [db_owner] ADD MEMBER [VISA2\625E9461C4204798819];


GO
ALTER ROLE [db_owner] ADD MEMBER [VISA2\nunco];


GO
ALTER ROLE [db_owner] ADD MEMBER [VISA2\ESIGAESC];


GO
ALTER ROLE [db_owner] ADD MEMBER [Usr_Pentaho];


GO
ALTER ROLE [db_owner] ADD MEMBER [VISA2\ESINIFER];


GO
ALTER ROLE [db_owner] ADD MEMBER [VISA2\ESIARBEN];


GO
ALTER ROLE [db_owner] ADD MEMBER [BANELCO\usuarioautoldap];


GO
ALTER ROLE [db_owner] ADD MEMBER [BANELCO\cbanderbek];


GO
ALTER ROLE [db_owner] ADD MEMBER [BANELCO\lespindola];


GO
ALTER ROLE [db_owner] ADD MEMBER [VISA2\ESIOSCEP];


GO
ALTER ROLE [db_owner] ADD MEMBER [BANELCO\ellopis];


GO
ALTER ROLE [db_owner] ADD MEMBER [VISA2\ESIGUKLI];


GO
ALTER ROLE [db_ddladmin] ADD MEMBER [VISA2\Vsidaher];


GO
ALTER ROLE [db_ddladmin] ADD MEMBER [VISA2\ESIPAROM];


GO
ALTER ROLE [db_ddladmin] ADD MEMBER [VISA2\ESIGACAM];


GO
ALTER ROLE [db_ddladmin] ADD MEMBER [VISA2\Imple_SQL];


GO
ALTER ROLE [db_ddladmin] ADD MEMBER [VISA2\VSIFRSCA];


GO
ALTER ROLE [db_ddladmin] ADD MEMBER [usr_DW_odbc];


GO
ALTER ROLE [db_datareader] ADD MEMBER [Usr_transactions];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\VSIINROM];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\VSIKAGOM];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\VSIMADIM];


GO
ALTER ROLE [db_datareader] ADD MEMBER [Usr_Operations];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\ETCELLOG];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\Vsidaher];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\ESIPAROM];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\ESIGACAM];


GO
ALTER ROLE [db_datareader] ADD MEMBER [User_Consulta_TEST_BDP];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\VSIMAFER];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\USR_CONFIGURATIONS_QA_R];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\mbravo];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\amartinez];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\abalart];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\JIphemie];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\esotelo];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\nunco];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\ESIJUBAR];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\ESIGAESC];


GO
ALTER ROLE [db_datareader] ADD MEMBER [BANELCO\JRAMOS];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\ESIDIHIN];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\ESIARBEN];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\VSIIGLAS];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\Amaldonado];


GO
ALTER ROLE [db_datareader] ADD MEMBER [BANELCO\usuarioautoldap];


GO
ALTER ROLE [db_datareader] ADD MEMBER [testautosql];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\2247D3F6BDB14777B7B];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\272C4202710546089AC];


GO
ALTER ROLE [db_datareader] ADD MEMBER [BANELCO\LRibles];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\4FAC1C77E9BC4F4F93B];


GO
ALTER ROLE [db_datareader] ADD MEMBER [BANELCO\fscarpello];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\ESINOAGU];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\ESILESEQ];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\AF0A13EB56204B93A29];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\Imple_SQL];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\IngServ_SQL];


GO
ALTER ROLE [db_datareader] ADD MEMBER [BANELCO\mrodrigues];


GO
ALTER ROLE [db_datareader] ADD MEMBER [BANELCO\ellopis];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\VSIJORAM];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\VSIFRSCA];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\VTCALMAR];


GO
ALTER ROLE [db_datareader] ADD MEMBER [BANELCO\palvarez];


GO
ALTER ROLE [db_datareader] ADD MEMBER [BANELCO\dbriasco];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\esicomar];


GO
ALTER ROLE [db_datareader] ADD MEMBER [BANELCO\jbednarz];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\ESIROTOR];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\ESIESDUE];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\ESIALBAR];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\ESIMADIA];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\ESIGUKLI];


GO
ALTER ROLE [db_datareader] ADD MEMBER [VISA2\ESISETIR];


GO
ALTER ROLE [db_datareader] ADD MEMBER [usr_DW_odbc];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [VISA2\Vsidaher];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [VISA2\ESIPAROM];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [VISA2\ESIGACAM];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [VISA2\mbravo];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [VISA2\amartinez];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [VISA2\ESIGAESC];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [BANELCO\JRAMOS];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [VISA2\ESIDIHIN];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [VISA2\ESIARBEN];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [BANELCO\usuarioautoldap];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [testautosql];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [VISA2\2247D3F6BDB14777B7B];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [VISA2\272C4202710546089AC];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [VISA2\4FAC1C77E9BC4F4F93B];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [BANELCO\fscarpello];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [VISA2\Imple_SQL];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [BANELCO\ellopis];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [VISA2\VSIJORAM];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [VISA2\VSIFRSCA];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [VISA2\VTCALMAR];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [BANELCO\palvarez];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [BANELCO\dbriasco];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [VISA2\esicomar];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [BANELCO\jbednarz];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [VISA2\ESIROTOR];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [usr_DW_odbc];

