﻿CREATE USER [VISA2\abalart] FOR LOGIN [VISA2\abalart];

