﻿CREATE USER [VISA2\mbravo] FOR LOGIN [VISA2\mbravo];

