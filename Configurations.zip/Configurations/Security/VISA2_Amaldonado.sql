﻿CREATE USER [VISA2\Amaldonado] FOR LOGIN [VISA2\Amaldonado];

