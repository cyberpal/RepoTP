﻿CREATE USER [VISA2\amartinez] FOR LOGIN [VISA2\amartinez];

