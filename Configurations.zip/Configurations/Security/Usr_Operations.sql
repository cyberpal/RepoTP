﻿CREATE USER [Usr_Operations] FOR LOGIN [Usr_Operations];

