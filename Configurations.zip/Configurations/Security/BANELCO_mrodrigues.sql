﻿CREATE USER [BANELCO\mrodrigues] FOR LOGIN [BANELCO\mrodrigues];

