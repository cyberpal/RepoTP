﻿CREATE USER [User_Consulta_TEST_BDP] FOR LOGIN [User_Consulta_TEST_BDP];

