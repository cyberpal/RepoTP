﻿CREATE USER [Usr_Configurations] FOR LOGIN [Usr_Configurations];

