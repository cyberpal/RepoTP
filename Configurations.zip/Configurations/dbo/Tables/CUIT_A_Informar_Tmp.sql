﻿CREATE TABLE [dbo].[CUIT_A_Informar_Tmp] (
    [cuit]         VARCHAR (50) NULL,
    [id_cuenta]    INT          NULL,
    [codigo_banco] VARCHAR (3)  NULL
);

