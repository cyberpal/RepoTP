﻿CREATE TABLE [dbo].[archivo_distribucion_medio_pago_tmp] (
    [id_admp]        SMALLINT      IDENTITY (1, 1) NOT NULL,
    [archivo_salida] VARCHAR (16)  NULL,
    [registro]       VARCHAR (145) NULL,
    [codigo]         VARCHAR (20)  NULL
);

