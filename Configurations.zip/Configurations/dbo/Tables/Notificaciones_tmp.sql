﻿CREATE TABLE [dbo].[Notificaciones_tmp] (
    [id_conciliacion] INT           NULL,
    [body_json]       VARCHAR (350) NULL,
    [url_servicio]    VARCHAR (200) NULL
);

