﻿CREATE TABLE [dbo].[Archivo_DisponibleLiquidacion_tmp] (
    [nombre_archivo] VARCHAR (100) NULL,
    [registro]       VARCHAR (200) NULL
);

