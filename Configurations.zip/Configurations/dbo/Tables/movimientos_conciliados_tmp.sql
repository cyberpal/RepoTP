﻿CREATE TABLE [dbo].[movimientos_conciliados_tmp] (
    [Id]               VARCHAR (36) NULL,
    [id_movimiento_mp] INT          NULL
);

