﻿CREATE TABLE [dbo].[Listado_Actividades_AFIP_v1.1] (
    [codigo_actividad_AFIP] NVARCHAR (50) NULL,
    [descripcion]           NVARCHAR (50) NULL
);

