﻿CREATE SEQUENCE [dbo].[secuencia_grupo_limite]
    AS BIGINT
    START WITH 50
    INCREMENT BY 1;

